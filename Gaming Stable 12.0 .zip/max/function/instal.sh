#!/system/bin/sh
apply() {
settings put global window_animation_scale 0.8
settings put global transition_animation_scale 0.8
settings put global animator_duration_scale 0.8
settings put global block_untrusted_touches 0
settings put secure touch_blocking_period 0
settings put secure tap_duration_threshold 0
settings put system multicore_packet_scheduler 1
settings put global enhanced_processing 2
settings put system rakuten_denwa 0
settings put system send_security_reports 0
settings put global sem_enhanced_cpu_responsiveness 1
settings put global cached_apps_freezer enabled
settings put system mcf_continuity 0
settings put secure game_auto_tempature 0
settings put global restrict_device_performance 0
settings put global power_check_max_cpu_1 80
settings put global power_check_max_cpu_2 80
settings put global power_check_max_cpu_3 55
settings put global power_check_max_cpu_4 55
settings put global device_idle_constants inactive_to=60000,sensing_to=0,locating_to=0,location_accuracy=2000,motion_inactive_to=0,idle_after_inactive_to=0,idle_pending_to=60000,max_idle_pending_to=120000,idle_pending_factor=2.0,idle_to=900000,max_idle_to=21600000,idle_factor=2.0,max_temp_app_whitelist_duration=60000,mms_temp_app_whitelist_duration=30000,sms_temp_app_whitelist_duration=20000,light_after_inactive_to=10000,light_pre_idle_to=60000,light_idle_to=180000,light_idle_factor=2.0,light_max_idle_to=900000,light_idle_maintenance_min_budget=30000,light_idle_maintenance_max_budget=60000
cmd appops set com.google.android.gms RUN_IN_BACKGROUND ignore
cmd appops set com.google.android.gms RUN_ANY_IN_BACKGROUND ignore
cmd appops set com.google.android.gms START_FOREGROUND ignore
cmd appops set com.google.android.gms INSTANT_APP_START_FOREGROUND ignore
cmd appops set com.google.android.ims RUN_IN_BACKGROUND ignore
cmd appops set com.google.android.ims RUN_ANY_IN_BACKGROUND ignore
cmd appops set com.google.android.ims START_FOREGROUND ignore
cmd appops set com.google.android.ims INSTANT_APP_START_FOREGROUND ignore
settings put secure allow_heat_cooldown_schedule false
settings put secure allow_heat_cooldown_always 0
settings put secure heat_cooldown_schedule 0
settings put secure allow_more_heat_value 50
settings put system pointer_speed 7
cmd power set-fixed-performance-mode-enabled true
cmd thermalservice override-status 0
cmd power set-mode 3
cmd settings put system log_thermalservice 0
setprop debug.hwc.showfps 0
setprop debug.sf.showupdates 0
setprop debug.sf.showcpu 0
setprop debug.sf.showbackground 0
setprop debug.sf.showfps 0  
setprop debug.hwc.force_gpu_reset_on_hotplug true
setprop debug.sf.hwc.min.duration 0
setprop debug.windowsmgr.max_events_per_sec 240
setprop debug.egl.force_msaa false
setprop debug.egl.force_fxaa false
setprop debug.egl.force_taa false
setprop debug.egl.force_smaa false
setprop debug.egl.force_txaa false
setprop debug.cpurend.vsync false
setprop debug.kill_allocating_task 0
setprop debug.overlayui.enable 1
setprop debug.hwui.texture_cache_size 0
setprop debug.force_rtl false
setprop debug.hw2d.force true
setprop debug.hw3d.force true
setprop debug.hwui.render_quality low
setprop debug.egl.profiler 0
setprop debug.egl.log_config 0
setprop debug.surface_flinger.vsync_sf_event_phase_offset_ns 0
setprop debug.systemuicompilerfilter speed
setprop debug.performance.tuning 1
setprop debug.performance.profile 1
setprop debug.qcom.hw_haplite 1
setprop debug.renderer.process 0
setprop debug.sf.disable_client_composition_cache 1
setprop debug.hwui.composition 0
setprop debug.hwui.fps_divisor 1
setprop debug.hwui.show_draw_order 0
setprop debug.hwui.render_dirty_regions 1
setprop debug.hwui.show_dirty_regions false
setprop debug.sf.enable_gl_backpressure 1
setprop debug.stagefright.omx_default_rank.sw-audio 1
setprop debug.sf.enable_hgl 1
setprop debug.sf.enable_hwc_vds 1
setprop debug.ums.hardware true
setprop debug.sf.enable_transaction_tracing true
setprop debug.sf.frame_rate_multiple_threshold 3
setprop debug.sf.gpu_comp_tiling 1
setprop debug.sf.gpu_freq_index 1
setprop debug.sf.hw 0
setprop debug.sf.disable_backpressure 1
setprop debug.sf.early_app_phase_offset_ns 500000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.sf.early_gl_phase_offset_ns 3000000
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.enable_hwc_vds 0
setprop debug.sf.high_fps_early_gl_phase_offset_ns 9000000
setprop debug.sf.high_fps_early_phase_offset_ns 6100000
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000
setprop debug.tracing.screen_state 0
setprop debug.qctwa.statusbar 1
setprop debug.gr.swapinterval 0
setprop debug.qctwa.preservebuf 1
setprop debug.qc.hardware true
setprop debug.cpu_core_ctl_active 1
setprop debug.hwui.disable_scissor_opt false
setprop debug.hwui.texture_cache_size 24
setprop debug.hwui.layer_cache_size 16
setprop debug.hwui.drop_shadow_cache_size 2
setprop debug.sf.enable_advanced_sf_phase_offset 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_hwc_vds 0
setprop debug.sf.high_speed_scroll_factor 25
setprop debug.hwui.textureformat etc2
setprop debug.hwui.target_power_time_percent 100
setprop debug.hwui.target_cpu_time_percent 100
setprop debug.hwui.target_gpu_time_percent 100
setprop debug.hwui.use_hint_manager true
setprop debug.egl.traceGpuCompletion 100
setprop security.perf_harden 0
setprop debug.cpurend.vsync false
cmd package force-dex-opt com.android.systemui
cmd package compile -r bg-dexopt -f com.android.systemui
cmd package compile -m everything -f com.android.systemui
cmd package compile -r first-boot -f com.android.systemui
cmd package compile -m everything --secondary-dex -f com.android.systemui
cmd package compile -r bg-dexopt --check-prof true -f com.android.systemui
cmd package compile -r bg-dexopt --secondary-dex -f com.android.systemui
cmd package compile -m everything --check-prof true -f com.android.systemui
cmd package compile -r shared --secondary-dex -f com.android.systemui
cmd package compile -r shared --secondary-dex com.android.systemui
cmd package reconcile-secondary-dex-files com.android.systemui
cmd device_config put systemui max_fling_velocity 20000
cmd device_config put systemui min_fling_velocity 8000
cmd device_config put systemui max_event_per_sec 200
cmd device_config put systemui scrollingcache 3
}
apply > /dev/null 2>&1
