gms() {
pm disable --user 0 com.google.android.gms/.chimera.GmsIntentOperationService
pm disable --user 0 com.google.android.apps.messaging/.shared.analytics.recurringmetrics..AnalyticsAlarmReceiver
pm disable --user 0 com.google.android.location.internal.UPLOAD_ANALYTICS
pm disable --user 0 com.google.android.apps.wellbeing/.powerstate.impl.PowerStateJobService
pm disable --user 0 com.google.android.apps.wellbeing/androidx.work.impl.background.systemjob.SystemJobService
pm disable --user 0 com.facebook.katana/com.facebook.analytics.appstatelogger.AppStateIntentService
pm disable --user 0 com.facebook.orca/com.facebook.analytics.apptatelogger.AppStateIntentService
pm disable --user 0 com.facebook.orca/com.facebook.analytics2.Logger.LollipopUploadService
pm disable --user 0 com.google.android.gms/com.google.android.gms.nearby.bootstrap.service.NearbyBootstrapService
pm disable --user 0 com.google.android.gms/NearbyMessagesService
pm disable --user 0 com.google.android.gms/com.google.android.gms.nearby.connection.service.NearbyConnectionsAndroidService
pm disable --user 0 com.google.android.gms/com.google.location.nearby.direct.service.NearbyDirectService
pm disable --user 0 com.google.android.gms/com.google.android.gms.lockbox.LockboxService
pm disable --user 0 com.google.android.gms/.measurement.PackageMeasurementTaskService
pm disable --user 0 com.google.android.gms/com.google.android.gms.auth.trustagent.GoogleTrustAgent
pm disable --user 0 com.google.android.gms/com.google.android.gms.analytics.AnalyticsTaskService
pm disable --user 0 com.google.android.gms/com.google.android.gms.analytics.service.AnalyticsService
pm disable --user 0 com.google.android.gms/com.google.android.gms.analytics.AnalyticsReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.ads.cache.CacheBrokerService
pm disable --user 0 com.google.android.gms/com.android.billingclient.api.ProxyBillingActivity
pm disable --user 0 com.google.android.gms/com.google.android.gms.ads.measurement.GmpConversionTrackingBrokerService
pm disable --user 0 com.google.android.gms/com.google.android.gms.ads.config.FlagsReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.analytics.AnalyticsService
pm disable --user 0 com.google.android.gms/com.google.android.gms.measurement.service.MeasurementBrokerService
pm disable --user 0 com.google.android.gms/com.google.android.gms.ads.adinfo.AdvertisinglnfoContentProvider
pm disable --user 0 com.google.android.gms/com.google.android.gms.measurement.AppMeasurementReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.ads.AdRequestBrokerService
pm disable --user 0 com.google.android.gms/com.google.android.gms.ads.jams.NegotiationService
pm disable --user 0 com.google.android.gms/com.google.android.gms.ads.AdRequestBrokerService
pm disable --user 0 com.google.android.gms/com.google.android.gms.ads.jams.NegotiationService
pm disable --user 0 com.google.android.gms/com.google.android.gms.measurement.AppMeasurementService
pm disable --user 0 com.google.android.gms/com.google.android.gms.measurement.PackageMeasurementService
pm disable --user 0 com.google.android.gms/com.google.android.gms.ads.social.GcmSchedulerWakeupService
pm disable --user 0 com.google.android.gms/com.google.android.gms.measurement.PackageMeasurementTaskService
pm disable --user 0 com.google.android.gms/com.google.android.gms.measurement.PackageMeasurementReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.measurement.AppMeasurementJobService
pm disable --user 0 com.google.android.gms/com.google.android.gms.ads.identifier.service.AdvertisingldService
pm disable --user 0 com.google.android.gms/com.google.android.gms.ads.GservicesValueBrokerService
pm disable --user 0 com.google.android.gms/com.google.android.gms.ads.settings.AdsSettingsActivity
pm disable --user 0 com.google.android.gms/com.google.android.gms.ads.identifier.service.AdvertisingldNotificationService
pm disable --user 0 com.google.android.gms/com.google.android.gms.analytics.internal.PlayLogReportingService

}
gms > /dev/null 2>&1