#!/system/bin/sh
# Credits @Khaliq_22

# Fungsi untuk mengatur prioritas I/O
ionice_process() {
  pkg=$1
  proc=$2
  ionice_class=$3
  ionice_priority=$4

  # Validasi parameter class dan priority
  if [[ $ionice_class -ge 0 && $ionice_class -le 3 && $ionice_priority -ge 0 && $ionice_priority -le 7 ]]; then
    ionice -t -c $ionice_class -n $ionice_priority -p $pkg >/dev/null 2>&1
  fi
}


# Membaca daftar paket dan proses dari file
package_list=$(ps | grep -o ".*[.][a-z]*" | awk '{print $2}')
process_list=$(ps | grep -o ".*[.][a-z]*" | awk '{print $9}' | cut -d "@" -f 1)

# Memisahkan paket dan proses ke dalam array
packages=($package_list)
processes=($process_list)

total_processes=${#packages[@]}  # Total number of processes
counter=1

# Kelompokkan proses berdasarkan prioritas
for i in "${!packages[@]}"; do
  pkg=${packages[i]}
  proc=${processes[i]}
  category="Default"
  ionice_class=3  # Default to "best-effort=2"
  ionice_priority=3  # Default priority "5"

  # Proses Inti
  if [[ "$proc" == *"com.coloros"* || "$proc" == *"com.samsung"* || "$proc" == *"com.transsion"* || "$proc" == *"com.miui"* || "$proc" == *"com.vivo"* || "$proc" == *"com.sonyericsson"* ]]; then
    category="Proses Inti"
    ionice_class=3  # Set class to "real-time=1"
    ionice_priority=5  # Set priority to "3"

  # Proses Hardware Inti
  elif [[ "$proc" == *"mediatek"* || "$proc" == *"android"* || "$proc" == *"android.hardware"* || "$proc" == *"vendor.qti.hardware"* ]]; then
    category="Proses Hardware Inti"
    ionice_class=2  # Set class to "real-time=1"
    ionice_priority=4  # Set priority to "4"

  # Paket Inti
  elif [[ "$pkg" == *"com.android"* ]]; then
    category="Paket Inti"
    ionice_class=2  # Set class to "best-effort=2"
    ionice_priority=7  # Set priority to "3"

  games=$(cat "/sdcard/max/function/Game.txt")
  elif echo "$games" | grep -q "$proc"; then
    category="Game Process"
    ionice_class=2  # Set class to "real-time=1"
    ionice_priority=4  # Set priority to "4"
  fi

  ionice_process $pkg $proc $ionice_class $ionice_priority
  ((counter++))
done
