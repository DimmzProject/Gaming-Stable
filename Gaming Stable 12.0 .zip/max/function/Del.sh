#!/system/bin/sh
Info="/storage/emulated/0"
Info0="/data/local/tmp/"
Info1="/data/local/tmp/run.sh"
Info2="/data/local/tmp/Ai.sh"
Info3="/data/local/tmp/function/instal.sh"
Info4="Detected Info Killing"
echo ""
echo "[ ! ] Detected $Info"
sleep 2
echo "[ ! ] Detected $Info0"
sleep 2
echo "[ ! ] Detected $Info1"
sleep 2
echo "[ ! ] Detected $Info2"
sleep 2
echo "[ ! ] Detected $Info3"
sleep 2
echo "[ ! ] Detected $Info4"
sleep 2
echo "[ ! ] Process of Erasing All Codes"
sleep 2
echo "[ ! ] Automatic Reboot Not support All Device"
sleep 2
(
pm enable --user 0 com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm enable --user 0 com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
settings delete system multicore_packet_scheduler
settings delete global enhanced_processing
settings delete system rakuten_denwa
settings delete system send_security_reports
settings delete global sem_enhanced_cpu_responsiveness
settings delete global cached_apps_freezer
settings delete system mcf_continuity
settings delete secure game_auto_tempature
settings delete global app_standby_enabled
settings delete global power_check_max_cpu_1
settings delete global power_check_max_cpu_2
settings delete global power_check_max_cpu_3
settings delete global power_check_max_cpu_4
settings delete secure allow_heat_cooldown_schedule
settings delete secure allow_heat_cooldown_always
settings delete secure heat_cooldown_schedule
settings delete secure allow_more_heat_value
#thx modz
#System
cmd settings reset --user 0 system untrusted_defaults
cmd settings reset --user 0 system untrusted_clear
cmd settings reset --user 0 system trusted_defaults
cmd settings reset --user 0 system case-insensitive
#Secure
cmd settings reset --user 0 secure untrusted_defaults
cmd settings reset --user 0 secure untrusted_clear
cmd settings reset --user 0 secure trusted_defaults
cmd settings reset --user 0 secure case-insensitive
#Global
cmd settings reset --user 0 global untrusted_defaults
cmd settings reset --user 0 global untrusted_clear
cmd settings reset --user 0 global trusted_defaults
cmd settings reset --user 0 global case-insensitive
pkill -9 -f Ai.sh
reboot
)> /dev/null 2>&1
echo "[ ! ] Done Kill All Code $Info0"
sleep 2