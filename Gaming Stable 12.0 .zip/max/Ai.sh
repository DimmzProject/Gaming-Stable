#!/system/bin/sh
{
apps=$(
printf "'DIMMZZZ"
for game in $(cat "/sdcard/max/function/Game.txt"); do
printf "|$game"
done
printf "'"
)
while true; do
  game=$(dumpsys window | grep "Window #" | grep WindowStateAnimator | grep -v "Window #0" | grep -Eo "$apps")
  mode=$(getprop debug.Ram.auto.kill)
  if [ ! "$game" ]; then
    if [ ! "$mode" = off ]; then
cmd power set-adaptive-power-saver-enabled true
cmd power set-fixed-performance-mode-enabled false
settings put global zen_mode 0
settings put system vibrate_when_ringing 1
dumpsys deviceidle enable
dumpsys deviceidle force-idle
dumpsys deviceidle step deep
settings put global heads_up_notifications_enabled 1
listgapps=$(pm list packages | cut -f 2 -d ":" | grep -e google | grep -v "com.google.android.inputmethod.latin")
for package in $listgapps; do
    pm enable --user 0 $package
done
setprop debug.Ram.auto.kill off
cmd notification post -S bigtext -t 'Gaming Stable' 'Tag' 'Batery Saver🔋'
      su -lp 2000 -c "cmd notification post -S bigtext -t 'Gaming Stable' 'Tag' 'Batery Saver🔋'"
    fi
  fi
  if [ "$game" ]; then
  if [ ! "$mode" = on ]; then  
    killed_background_apps=false
    for pkg in $(cmd package list packages -3 | cut -f 2 -d : | grep -Ev "$apps"); do
      if [ ! "$killed_background_apps" = true ]; then
        am force-stop --user 0 $pkg
        am kill --user 0 $pkg
        killed_background_apps=true 
      fi
    done
  listgapps=$(pm list packages | cut -f 2 -d ":" | grep -e google | grep -v "com.google.android.inputmethod.latin")
    for package in $listgapps; do
      pm disable --user 0 $package
    done
    settings put global zen_mode 1
    settings put system vibrate_when_ringing 0
    settings put global heads_up_notifications_enabled 1
    cmd power set-adaptive-power-saver-enabled false
    cmd power set-fixed-performance-mode-enabled true
    cmd power set-mode 0
    am memory-factor set CRITICAL
    cmd thermalservice override-status 0
    cmd looper_stats disable
    dumpsys deviceidle whitelist -com.google.android.gms
    setprop debug.Ram.auto.kill on

    cmd notification post -S bigtext -t 'Gaming Stable' 'Tag' 'Performance On'
    su -lp 2000 -c "cmd notification post -S bigtext -t 'Gaming Stable' 'Tag' 'Performance On'"
  fi
fi
sleep 10
done
} > /dev/null 2>&1
