
## Introduction

This script is designed to optimize the performance of an Android device by applying various system settings, disabling logging, and managing application performance modes. It includes tweaks to improve graphics performance, reduce CPU throttling, and manage device configurations dynamically based on game detection.

## Features & Script Breakdown 
- **Customization**: Applies various system tweaks to enhance performance.
- **Fast UI Compilation**: Forces dex optimization on the system UI to improve responsiveness.
- **Logging Disable**: Disables all logging to free up system resources.
- **Game Boosting**: Automatically detects and optimizes installed games.
- **System Configuration Tweaks**: Adjusts settings related to CPU, GPU, thermal management, and power modes.
- **Fast UI Optimization**: Compiles and optimizes the system UI for better performance.
- **Device Information Display**: Shows relevant device information such as brand, model, CPU, GPU, and SDK version.
- **Network Performance Tuning**: Optimizes network performance by adjusting settings related to network bandwidth and latency.
- **Battery Optimization**: Configures battery settings for maximum efficiency, including disabling background activities for non-essential apps.
- **Thermal Management**: Enhances thermal management by adjusting the thermal throttling settings and cooling profiles.
- **I/O Priority Adjustment**: Controls how disk (or I/O) resources are allocated between processes running on the system to optimize performance and efficiency.
- **Custom Rendering Options**: Allows users to select different rendering engines to optimize graphics performance based on personal preference or device capabilities.
- **Disable Thermal Mode for Vivo Devices**: Automatically detects Vivo devices and disables thermal throttling to enhance performance.

### New Feature Explanations
1. **Network Performance Tuning**: Optimizes network settings by disabling background restrictions and enabling Wi-Fi scanning availability.
2. **Battery Optimization**: Disables battery saver settings and adaptive battery management to enhance application performance.
3. **Thermal Management**: Adjusts thermal management to prevent excessive throttling and improve performance stability.
4. **I/O Priority**: Adjusts I/O priority settings to control how disk resources are allocated, optimizing system performance and efficiency.
5. **Custom Rendering Options**: Provides a menu for users to select different rendering engines including:
    - **Angle**: Uses the ANGLE rendering engine.
    - **OpenGL**: Uses the OpenGL rendering engine.
    - **SkiaGL**: Uses the SkiaGL rendering engine.
    - **SkiaVK**: Uses the SkiaVK rendering engine.
    - **Vulkan**: Uses the Vulkan rendering engine.
    - **Optimize Rendering**: Applies rendering optimization settings.
    - **Delete Optimize Rendering**: Removes rendering optimization settings.
    - **Exit App Brevent**: Exits the Brevent application.
6. **Disable Thermal Mode for Vivo Devices**: Detects if the device is a Vivo device and disables thermal throttling by setting `bench_mark_mode` to 1. This prevents the device from reducing performance due to thermal constraints, ensuring consistent high performance during intensive tasks or gaming.
7. **Heat Management**: Configures settings to manage device temperature, preventing unnecessary cooldown schedules and allowing higher heat values for better performance stability. The specific settings adjusted are:
    - **Disable Heat Cooldown Schedule**: Prevents the device from following default heat cooldown schedules.
    - **Disable Always Allow Heat Cooldown**: Ensures the device doesn't always allow heat cooldown processes.
    - **Set Heat Cooldown Schedule**: Defines a specific schedule for heat cooldown, set to 0 to disable.
    - **Allow More Heat Value**: Allows the device to tolerate higher temperatures before throttling (set to 46°C in this case).


These additional features will help optimize not only the system performance but also network settings, battery management, thermal management, and graphics performance of your device.

## Installation
To install the script, run:
```sh
sh /sdcard/max/run.sh
1 #skiagl(contoh
```

## Uninstallation
To uninstall or remove the script, run:
```sh
sh /sdcard/max/function/delete.sh
```

**Note**: Execute commands through Brevent or other shell utilities as needed.

## Author
- **Developer**: DIMMZZGOOD

## Notes
- **Custom Settings**: The script includes custom settings that might not be applicable to all devices. Adjust them as needed.
- **Logging**: Disabling logging can improve performance but may make troubleshooting more difficult.

## Disclaimer
This script is provided as-is without any warranty. Use it at your own risk. The author is not responsible for any damage that may occur to your device.

## Credits
- **Developer**: DIMMZZGOOD
- **Special Thanks**: Kazuyo for script contributions.

## Contact
For more information, visit the [Telegram Channel](https://t.me/DimzOpenSourcee).
@DIMMZZGOOD

