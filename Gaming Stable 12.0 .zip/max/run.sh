#!/bin/bash
#Thanks to Kazuyo
#Thanks To All Contributor
# Collecting properties related to logging
log_prop=$(getprop | grep debug.log | cut -d: -f1 | sed 's/[][]//g' && getprop | grep log.tag. | cut -d: -f1 | sed 's/[][]//g' && getprop | grep persist.log.tag | cut -d: -f1 | sed 's/[][]//g')

MODDIR1="sh /sdcard/max/function/instal.sh"
MODDIR2="sh /sdcard/max/function/!!IO-Perf/IO.sh"
MODDIR3="sh /sdcard/max/properti/!!IO-Perf/!!/Gms.sh"
echo "This Files Copyright (c) 2024 DIMMZZGOOD™"
sleep 2
echo ""
echo "█▀▀ ▄▀█ █▀▄▀█ █ █▄░█ █▀▀  
█▄█ █▀█ █░▀░█ █ █░▀█ █▄█  

█▀ ▀█▀ ▄▀█ █▄▄ █░░ █▀▀
▄█ ░█░ █▀█ █▄█ █▄▄ ██▄"
sleep 2
echo ""
echo "##############################"
echo "╰─> Author       : @DIMMZZGOOD"
echo "╰─> Version      : 12 Beta"
echo "╰─> Support Me  : 089515001716 (Dana)"
echo "##############################"
sleep 1
echo "NOTE"
echo "╰─> This File is Copyrighted "
sleep 2
echo "[ - ] Installing Custom Rendering, Please choose"
sleep 0.3

option1() {
    # Open GL Engine
    echo ""
    echo "• Render Saat Ini : [ $selected_option ]"
    echo ""
    setprop persist.log.tag.snet_event_log ""
    setprop persist.log.tag ""
    setprop debug.sf.use_frame_rate_priority 1
    setprop debug.hwui.skip_empty_damage true
    setprop debug.hwui.renderer opengles
    setprop debug.renderengine.backend openglesthreaded
    setprop debug.opengles.overlay FPS:opengles*PipelineCache*
}

option2() {
    # Skia GL Engine
    echo ""
    echo "• Render Saat Ini : [ $selected_option ]"
    echo ""
    setprop persist.log.tag.snet_event_log ""
    setprop persist.log.tag ""
    setprop debug.sf.use_frame_rate_priority 1
    setprop debug.hwui.skip_empty_damage true
    setprop debug.hwui.renderer skiagl
    setprop debug.renderengine.backend skiaglthreaded
    setprop debug.skiagl.overlay FPS:skiagl*PipelineCache*
}

option3() {
    # Skia VK Engine
    echo ""
    echo "• Render Saat Ini : [ $selected_option ]"
    echo ""
    setprop persist.log.tag.snet_event_log ""
    setprop persist.log.tag ""
    setprop debug.sf.use_frame_rate_priority 1
    setprop debug.hwui.skip_empty_damage true
    setprop debug.hwui.renderer skiavk
    setprop debug.hwui.shadow.renderer skiavk
    setprop debug.renderengine.backend skiavkthreaded
    setprop debug.skiavk.overlay FPS:skiavk*PipelineCache*
}

option4() {
    # Vulkan Engine
    echo ""
    echo "• Render Saat Ini : [ $selected_option ]"
    echo ""
    setprop debug.hwui.renderer vulkan
    setprop debug.renderengine.backend vulkanthreaded
    setprop debug.vulkan.overlay FPS:vulkan*PipelineCache*
    setprop debug.rs.shader SPIR-V
    setprop debug.hw.vsync 0
    setprop debug.generate-debug-info false
    setprop debug.egl.traceGpuCompletion false
    setprop persist.log.tag.snet_event_log ""
    setprop persist.log.tag ""
    setprop debug.sf.use_frame_rate_priority 1
    setprop debug.rs.visual vulkan
    setprop debug.hwui.skip_empty_damage true
}

option5() {
    # Optimization Render
    echo ""
    echo "• Status : [ $selected_option ]"
    echo ""
    settings put global hardware_accelerated_gpu_schedule 1
    settings put global hardware_accelerated_graphics_decoding 1
    settings put global hardware_accelerated_rendering_enabled 1
}

option6() {
    # Deletion Optimize Rendering
    echo ""
    echo "• Status : [ $selected_option ]"
    echo ""
    settings delete global hardware_accelerated_gpu_schedule >/dev/null 2>&1
    settings delete global hardware_accelerated_graphics_decoding >/dev/null 2>&1
    settings delete global hardware_accelerated_rendering_enabled >/dev/null 2>&1
}

echo "[ * ] Pilihan Menu Rendering :"
echo " 1. OpenGL"
echo " 2. SkiaGL"
echo " 3. SkiaVK"
echo " 4. VulkanApi"
echo " 5. Optimize Rendering"
echo " 6. Deletion Optimize Rendering"

sleep 0.5
echo
echo -n " -> Menu : " 
read choice
case $choice in
1)
    selected_option="OpenGL"
    option1
    ;;
2)
    selected_option="SkiaGL"
    option2
    ;;
3)
    selected_option="SkiaVK"
    option3
    ;;
4)
    selected_option="VulkanApi"
    option4
    ;;
5)
    selected_option="Rendering Has Been Optimized"
    option5
    ;;
6)
    selected_option="Deletion Complete"
    option6
    ;;
esac

echo "[ ! ] Installing Disable All Logging & Cache"
sleep 2
# Disable All Logging and cache
logging_cmd () {
    for logging in $log_prop; do
        setprop "$logging" "-"
    done
    cmd activity clear-debug-app
    sm fstrim
    find /sdcard/Android/data/*/cache/* -delete
    am clear-watch-heap -a
    cmd stats clear-puller-cache
    
}

# Call function and run the process in the background
logging_cmd > /dev/null 2>&1 &
echo "[ - ] Successfully Disabled All Logging & Cache"
sleep 2

echo "[ ! ] Installing Property Tweaks"
sleep 2
"$MODDIR1" > /dev/null 2>&1 &
echo "[ - ] Successfully Installed Property Tweaks"
sleep 2

echo "[ ! ] Installing I/O Tweaks Adjust Performance"
sleep 2
"$MODDIR2" > /dev/null 2>&1 &
echo "[ ! ] Succes Installing I/O Tweaks Adjust Performance"
# Periksa apakah perangkat adalah Vivo
if getprop ro.product.manufacturer | grep -iq 'vivo'; then
echo "[ ! ] Perangkat terdeteksi sebagai Vivo. Mengaktifkan fitur Thermal mode..."    
# Fungsi untuk mengaktifkan Thermal mode
Thermal_mode () {
settings put system bench_mark_mode 1
if [ $? -eq 0 ]; then
echo "[ ! ] Fitur Thermal mode telah diaktifkan."
else
echo "[ - ] Gagal mengaktifkan fitur Thermal mode."
fi
}

# Jalankan fungsi Thermal_mode di latar belakang
Thermal_mode > /dev/null 2>&1 &
else
echo "[ - ] Perangkat bukan Vivo. Fitur Thermal mode tidak akan diaktifkan."
fi

echo "[ ! ] Installing Gms Doze for Battery Saving"
sleep 0.5
echo "[ ? ] I Don't Know Whether It Works Or Not"
sleep 2
"$MODDIR3" > /dev/null 2>&1 &
echo "[ - ] Successfully Installed Gms Doze with Optimized Battery"
sleep 2

# Reset all throttling
reset_throttling_cmd () {
cmd shortcut reset-all-throttling
cmd shortcut reset-throttling
}
# Call function and run the process in the background
reset_throttling_cmd > /dev/null 2>&1 &
package_list=$(cmd package list packages | cut -f 2 -d ":")
game_list=$(cat "/sdcard/max/function/Game.txt")
echo "$game_list" | while IFS= read -r game; do
line=$(echo "$game" | awk '!/ /')
if echo "$package_list" | grep -q "$line"; then
echo "｜Boosting $line"
fi
done
echo "If Your Game Is Not Detected
Edit (Game.txt)
Add (Package Name)
Restart Module
"
sh /sdcard/max/Ai.sh > /dev/null 2>&1 &
#          THANKS TO ALL CONTRIBUTOR
                      

#            Copyright © DIMMZZGOOD™


#                 ------------------------------
#            --  D I M M Z Z G O O D  --
#                  ------------------------------
